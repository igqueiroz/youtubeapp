import React, {Component}  from 'react'
import DestaquePrimario from './DestaquePrimario'

export const Destaque = () =>
     <section className="destaques">
      <div className="container">
        <DestaquePrimario />
       </div>
    </section>
 