import React, {Component}  from 'react'
import AllListPrimario from './AllListPrimario'

			
export const AllList = () =>
			<section className="results-page ">
				<div className="container">
					<div className="row">
				     	<div id="youtube-destaque-wrapper">
				     		<h1>Todos os vídeos do Canal</h1>
				     		<AllListPrimario />
				     	</div>
			   		</div>
			   </div>
			</section>
			
			




