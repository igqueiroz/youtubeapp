import React, {Component}  from 'react'
import SearchResultsPrimario from './SearchResultsPrimario'
import Menus from './Menus'

			
export const SearchResults = () =>
			<section className="results-page">
				<div className="container">
					<div className="row">
				     	<div id="youtube-destaque-wrapper">
				     		<SearchResultsPrimario />
				     	</div>
			   		</div>
			   </div>
			</section>
			
			




